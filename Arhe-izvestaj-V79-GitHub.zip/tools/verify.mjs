import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { createHash, randomBytes, webcrypto } from 'node:crypto';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const html = await readFile(join(root, 'index.html'), 'utf8');
const source = html.match(/<script>([\s\S]*?)<\/script>/)?.[1];
assert(source, 'Nedostaje skript aplikacije.');
new vm.Script(source);
assert.equal((html.match(/<script\b/gi) || []).length, 1);
const digest = createHash('sha256').update(source).digest('base64');
assert(html.includes("'sha256-" + digest + "'"), 'CSP otisak ne odgovara skriptu.');
assert(html.includes("connect-src 'none'"));
assert(!/demoPassword|ArheDemo|fill-login/.test(html), 'Ostali su demo pristupni podaci.');
assert(!/[A-Z]:[\\/](?:Users|Windows)/i.test(html), 'Lokalna putanja u HTML-u.');
assert(!/INC0000\d{6,}/.test(html), 'Stari INC identifikatori u HTML-u.');
assert(!/[\w.+-]+@[\w.-]+\.[a-z]{2,}/i.test(html), 'Ugrađena email adresa.');
assert(!/\b0[1-9][0-9]{7,10}\b/.test(html), 'Ugrađen telefonski broj.');
assert(!/(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)/.test(html));
assert(!/\b(?:fetch\s*\(|XMLHttpRequest|WebSocket\s*\(|sendBeacon\s*\(|eval\s*\(|new Function\s*\()/.test(source));
assert(!/\b(?:src|href)=["'](?:https?:|file:)/i.test(html), 'Spoljašnji ili lokalni apsolutni resurs.');
const assets = [...new Set([...html.matchAll(/assets\/[a-z0-9-]+\.png/g)].map(match => match[0]))];
assert.equal(assets.length, 4);
for (const asset of assets) {
  const bytes = await readFile(join(root, asset));
  assert.equal(bytes.subarray(1, 4).toString('ascii'), 'PNG');
}

const allowed = new Set(['index.html', 'README.md', 'SECURITY.md', 'ASSETS.md', '.gitignore', '.gitattributes', '.nojekyll', 'package.json', 'SHA256SUMS.txt', 'tools/verify.mjs', ...assets]);
const files = [];
async function walk(folder) {
  for (const entry of await readdir(folder, { withFileTypes: true })) {
    assert(!entry.isSymbolicLink(), 'Simbolički link nije dozvoljen u paketu.');
    const path = join(folder, entry.name);
    if (entry.isDirectory()) await walk(path);
    else {
      const name = relative(root, path).replaceAll('\\', '/');
      assert(allowed.has(name), 'Neočekivan fajl: ' + name);
      files.push(name);
    }
  }
}
await walk(root);
if (files.includes('SHA256SUMS.txt')) {
  const sums = (await readFile(join(root, 'SHA256SUMS.txt'), 'utf8')).trim().split('\n');
  assert.equal(sums.length, files.length - 1, 'Kontrolne sume ne pokrivaju sve fajlove.');
  for (const line of sums) {
    const match = /^([0-9a-f]{64})  (.+)$/.exec(line);
    assert(match && allowed.has(match[2]) && match[2] !== 'SHA256SUMS.txt');
    const actual = createHash('sha256').update(await readFile(join(root, match[2]))).digest('hex');
    assert.equal(actual, match[1], 'Izmenjen fajl: ' + match[2]);
  }
}

function storage() {
  const values = new Map();
  return { getItem: key => values.get(key) || null, setItem: (key, value) => values.set(key, String(value)), removeItem: key => values.delete(key) };
}
function node() {
  return { dataset: {}, hidden: false, innerHTML: '', textContent: '', style: { setProperty() {}, removeProperty() {} }, classList: { add() {}, remove() {}, toggle() {} }, querySelector() { return null; }, querySelectorAll() { return []; }, contains() { return false; }, setAttribute() {}, removeAttribute() {}, focus() {}, open: false, showModal() { this.open = true; }, close() { this.open = false; } };
}
const nodes = new Map(), localStorage = storage(), sessionStorage = storage();
localStorage.setItem('arhe-izvestaj:podaci', JSON.stringify({ legacySentinel: true }));
const testSecret = 'T' + randomBytes(14).toString('hex') + '9!';
const operatorSecret = 'O' + randomBytes(14).toString('hex') + '7!';
const context = vm.createContext({
  assert, console, crypto: webcrypto, TextEncoder, localStorage, sessionStorage, testSecret, operatorSecret,
  document: { getElementById: id => { if (!nodes.has(id)) nodes.set(id, node()); return nodes.get(id); }, documentElement: node(), addEventListener() {}, querySelectorAll: () => [] },
  window: { addEventListener() {}, matchMedia: () => ({ matches: false }) },
  navigator: { clipboard: { writeText: async () => {} } },
  setTimeout: () => 1, clearTimeout() {}, setInterval: () => 1, clearInterval() {}, requestAnimationFrame: () => 1, cancelAnimationFrame() {},
  FormData: class extends Map { constructor(form) { super(Object.entries(form || {})); } getAll(key) { const value = this.get(key); return value === undefined ? [] : Array.isArray(value) ? value : [value]; } }
});
vm.runInContext(source, context);
await vm.runInContext(`(async () => {
  assert.equal(data.users.length, 0);
  assert.equal(data.entries.length, 0);
  assert.equal(data.breaks.length, 0);
  assert.equal(data.notices.length, 0);
  assert.equal(Object.keys(WORKBOOK_SCHEDULE).length, 0);
  assert($('auth').innerHTML.includes('data-form="local-setup"'));
  assert.equal(JSON.parse(localStorage.getItem('arhe-izvestaj:podaci')).legacySentinel, true);
  await assert.rejects(() => createLocalManager({ name: 'Test Manager', username: 'test.manager', password: 'weak', confirm: 'weak' }));
  await createLocalManager({ name: 'Test Manager', username: 'test.manager', password: testSecret, confirm: testSecret });
  const managerId = userId;
  assert(isManager());
  assert(currentUser().hash && currentUser().salt);
  assert(!JSON.stringify(data).includes(testSecret));
  await assert.rejects(() => createLocalManager({ name: 'Second', username: 'second', password: testSecret, confirm: testSecret }));
  for (const section of Object.keys(NAV)) { view.section = section; render(); }
  logout();
  await assert.rejects(() => login({ username: 'test.manager', password: testSecret + 'wrong' }));
  publicActions.register();
  await register({ name: 'Test Operator', birthDate: '01.01.1990', contact: 'Test kontakt', address: 'Test unos', municipality: 'Test', city: 'Test' });
  await register({});
  await register({ username: 'test.operator', password: operatorSecret, confirm: operatorSecret });
  assert.equal(data.accountRequests.length, 1);
  assert(!JSON.stringify(data).includes(operatorSecret));
  await assert.rejects(() => login({ username: 'test.operator', password: operatorSecret }), /odobrenje/);
  await login({ username: 'test.manager', password: testSecret });
  assert.equal(userId, managerId);
  decide('account', data.accountRequests[0].id, 'approved');
  const operator = data.users.find(person => person.username === 'test.operator');
  assert(operator && operator.role === 'employee');
  assert.throws(() => savePermissions({ id: managerId, permission: [] }), /zaštićena/);
  logout();
  await login({ username: 'test.operator', password: operatorSecret });
  assert(!canAdmin());
  view.section = 'report'; view.reportUser = userId; view.reportDate = today();
  saveReportCell(1, REPORT_FIELDS.find(field => field.key === 'type'), 'Tiket');
  saveReportCell(1, REPORT_FIELDS.find(field => field.key === 'customer'), 'example.invalid');
  saveReportCell(1, REPORT_FIELDS.find(field => field.key === 'inc'), 'INC-EXAMPLE');
  saveReportCell(1, REPORT_FIELDS.find(field => field.key === 'status'), 'Smena', '', '16:30');
  assert.equal(dailyDashboard(today()).processed, 1);
  assert.equal(dailyDashboard(today()).handover[0].contactTime, '16:30');
  view.section = 'breaks'; reserveBreak({ start: '16:30', end: '17:00' });
  logout(); await login({ username: 'test.manager', password: testSecret });
  view.section = 'breaks';
  assert.throws(() => reserveBreak({ start: '16:01', end: '16:31' }), /preklapa/);
  reserveBreak({ start: '16:00', end: '16:30' });
  for (const section of Object.keys(NAV)) { view.section = section; render(); }
})()`, context);
console.log('OK: izvor, resursi, CSP, čišćenje podataka, prvi nalog, registracija, odobrenje, pristupi, dashboard i pauze.');
console.log('Provera je programska; ne predstavlja vizuelni pregled u pregledaču niti proveru produkcione bezbednosti.');
