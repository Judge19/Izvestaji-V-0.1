# Arhe izveštaj V79 — paket za GitHub

Očišćen statički prototip za izveštaje, raspored, pauze, šablone, procedure i dnevni pregled.

**Paket služi za pregled koda i probu lokalnog prototipa. Nema serversku autentifikaciju ni zajedničku bazu podataka. Za objavljeni prikaz koristi isključivo izmišljene podatke i probne lozinke.**

## Sadržaj

- `index.html`: aplikacija V79, stilovi i logika.
- `assets/`: četiri slike potrebne aplikaciji.
- `.nojekyll`: statički prikaz bez Jekyll obrade.
- `.gitignore`: pravila za izostavljanje privatnih dokumenata i lokalnih tajni.
- `.gitattributes`: čuva ujednačene završetke redova i binarni format slika.
- `SECURITY.md`: granice zaštite i uslovi za stvarnu timsku upotrebu.
- `tools/verify.mjs`: provera paketa bez dodatnih biblioteka.
- `package.json`: komanda za proveru; instaliranje paketa nije potrebno.
- `ASSETS.md`: opis vizuelnih materijala.
- `SHA256SUMS.txt`: kontrolne sume fajlova.

## Šta je očišćeno

Nema preuzetih Excel izveštaja ni rasporeda, ugrađenih profila kolega, korisničkih identifikatora iz primera, stvarnih INC brojeva, telefona i adresa iz ranijih primera, niti unapred postavljenih naloga i lozinki. Početno stanje je prazno. Generički operativni šabloni i funkcije ostaju dostupni; kontakt telefon iz jednog šablona zamenjen je oznakom za unos.

Nisu uključeni prethodni HTML fajlovi, snimci ekrana, prilozi, dokumenti, privremeni fajlovi, podaci iz tvog pregledača niti Git istorija. Radna V78 nije menjana. V79 koristi poseban prostor za lokalno čuvanje i ne preuzima podatke iz prethodne aplikacije.

## Pokretanje

1. Raspakuj ceo ZIP.
2. Otvori `index.html` u novijem Edge, Chrome ili Firefox pregledaču. Sačuvaj folder `assets/` pored njega.
3. Na prvom ekranu kreiraj **lokalni menadžerski nalog**. Nema podrazumevane lozinke.
4. Za isprobavanje operatera odjavi se, podnesi zahtev kroz Kreiraj nalog, pa se prijavi kao lokalni menadžer i odobri zahtev u Admin panelu.
5. Sve probne naloge i izmene vidiš samo u tom pregledaču i na tom poreklu sajta. Drugi pregledač ili računar ima zasebno prazno stanje i svog prvog lokalnog menadžera.

Pravila za konkretne operatere podešavaš nakon odobravanja njihovih naloga.

Brisanje podataka sajta ili lokalnog skladišta briše lokalne naloge i unose. Paket ne uključuje rezervnu kopiju starih podataka.

## Upload na GitHub

1. Napravi nov prazan repozitorijum. Za interni pregled koda koristi Private dok ne pregledaš sadržaj i prava na poslovne tekstove.
2. Dodaj **sadržaj raspakovanog foldera** tako da su `index.html`, `assets/` i ostali fajlovi neposredno u korenu repozitorijuma. ZIP se ne otvara automatski kao sajt.
3. Uključi `.gitignore`, `.gitattributes` i `.nojekyll`; fajlovi koji počinju tačkom mogu biti sakriveni u prikazu foldera.
4. Nemoj dodavati ceo radni folder, stare verzije, Excel dokumente ili izvoze sa unosima.
5. Ako stari repozitorijum već sadrži privatne podatke, ovaj paket ih ne uklanja iz njegove istorije. Koristi nov repozitorijum za očišćeni paket.

### Opcioni prikaz preko GitHub Pages

Ako tvoj GitHub plan dozvoljava Pages za izabrani repozitorijum, otvori **Settings → Pages**, izaberi **Deploy from a branch**, granu sa fajlovima i folder **/(root)**, pa sačuvaj. Nije potreban npm build.

**Privatan repozitorijum sam po sebi ne znači da je Pages sajt privatan.** Objavljuj samo prototip sa probnim podacima. Pages služi statičke fajlove; ne dodaje server za prijavljivanje ili timsku bazu.

Zvanična uputstva: [GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages) i [izbor izvora objavljivanja](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

## Provera

Ako imaš Node.js, iz korena raspakovanog paketa pokreni:

```text
node tools/verify.mjs
```

Ista provera dostupna je komandom `npm run check`. Nema zavisnosti za instalaciju. Provera ne koristi mrežu i ne menja podatke tvog pregledača.

## Stvarna timska upotreba

Pre stvarnih poslovnih i ličnih podataka potrebni su server, zajednička baza, serverska provera prava i bezbedne sesije. Detalji su u `SECURITY.md`. Odobravanje naloga, privatne beleške i zaštita menadžera ovde predstavljaju ponašanje interfejsa lokalnog prototipa.
