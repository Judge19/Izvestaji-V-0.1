# Bezbednosne granice V79

Čišćenje izvornog koda ne pretvara lokalni HTML u bezbedan višekorisnički sistem.

## Nalozi i pristupi

Nema ugrađenih naloga, poznate početne lozinke, API ključeva ili pristupnog tokena. Prvi nalog kreira posetilac lokalno u svom pregledaču. Pri kreiranju lozinka se obrađuje PBKDF2-SHA256 postupkom sa nasumičnom soli i 150000 iteracija; njen tekst se ne čuva u lokalnom skupu podataka.

Svi podaci, heševi i prava nalaze se u lokalnom skladištu pregledača. Vlasnik tog pregledača može ih videti ili promeniti kroz razvojne alate, uključujući svojstva menadžera. Provera prava u JavaScript-u i skrivanje dugmadi nisu serverska zaštita. Svaki novi posetilac objavljenog prototipa ima svoj nezavisan lokalni prostor.

Beleške dostupne vlasniku i menadžeru imaju to ograničenje kroz interfejs. Nisu kriptografski zaštićene od osobe koja ima pristup lokalnim podacima tog pregledača.

Koristi probne podatke i lozinku koju ne koristiš na drugim servisima. Prototip nema serversko vraćanje zaboravljene lozinke.

## Uključene mere

- Prazni početni izveštaji, nalozi i istorija; stara radna verzija se ne uvozi.
- Nema spoljnih biblioteka, CDN resursa, analitike ni mrežnog API-ja.
- Slike se učitavaju iz lokalnog foldera assets.
- Meta CSP proverava SHA-256 otisak uključenog skripta i zabranjuje mrežni API kroz connect-src 'none'. CSS ostaje inline zbog postojećeg interfejsa.
- Provera paketa proverava otisak skripta, resurse, rizične obrasce i osnovne tokove naloga.
- .gitignore sprečava deo slučajnih dodavanja privatnih fajlova; nije zamena za pregled pre slanja na GitHub.

Ako menjaš JavaScript, osveži SHA-256 otisak u CSP meta oznaci; u suprotnom će pregledač blokirati skript. Provera paketa prijavljuje neslaganje.

## Pre stvarne upotrebe

Potrebni su serverska autentifikacija i autorizacija za svaku radnju, zajednička baza sa kontrolom pristupa, bezbedne HTTP sesije, odgovarajuća zaštita saobraćaja, rezervne kopije i dnevnik promena. GitHub Pages sam ne pruža te funkcije. GitHub tajne i serverske lozinke nikad ne upisuj u HTML ili JavaScript.

Ne unosi stvarne izveštaje, podatke korisnika ili zaposlenih u javno objavljen prototip. Pre objave poslovnih tekstova proveri odobrenje vlasnika sadržaja. Paket ne sadrži originalne priložene Excel dokumente ili snimke ekrana.

Ručni upload kroz GitHub stranicu ne mora poštovati .gitignore. Uvek šalji samo sadržaj ovog očišćenog paketa i pregledaj spisak fajlova pre potvrde.
