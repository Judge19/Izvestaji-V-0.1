# Vizuelni materijali

- assets/login-background.png — svemirska pozadina prijave.
- assets/report-icon-64.png — ikonica kartice pregledača.
- assets/report-icon-128.png — ikonica dnevnog pregleda.
- assets/report-icon-180.png — apple-touch-icon.

Slike su generisane za ovaj projekat. Referentne slike, snimci ekrana, promptovi sa lokalnim putanjama i radni izvozi nisu deo paketa. Ovaj opis nije izjava o pravnom odobrenju poslovnog naziva ili drugog poslovnog sadržaja.
